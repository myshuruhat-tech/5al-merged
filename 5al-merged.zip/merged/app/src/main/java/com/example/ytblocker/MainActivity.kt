package com.example.ytblocker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private val cBg = Color.parseColor("#0A0A0C")
    private val cCard = Color.parseColor("#141418")
    private val cStroke = Color.parseColor("#2A2A32")
    private val cText = Color.parseColor("#F4F4F6")
    private val cMuted = Color.parseColor("#9A9AA6")
    private val cMint = Color.parseColor("#34D399")
    private val cBlue = Color.parseColor("#60A5FA")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(40), dp(18), dp(40))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(text("اختر التطبيق", 24f, cText, true))
        root.addView(card("حجب قنوات يوتيوب", "السجل وحالة الخدمة", cMint, BlockerActivity::class.java))
        root.addView(card("نتايج", "نتائج المباريات والدوريات", cBlue, ResultsActivity::class.java))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(cBg)
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
    }

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
    }

    private fun card(title: String, sub: String, accent: Int, target: Class<*>): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            background = GradientDrawable().apply {
                setColor(cCard)
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), cStroke)
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(16) }
            gravity = Gravity.START
            addView(text(title, 20f, accent, true))
            addView(text(sub, 13f, cMuted).apply { setPadding(0, dp(6), 0, 0) })
            isClickable = true
            setOnClickListener { startActivity(Intent(this@MainActivity, target)) }
        }
}
